let plateau = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0]
];

const img = new Map();
img.set("X", "./images/blue.png");
img.set("O", "./images/red.png");

let turn;

function newGame() {
    turn = "X";
    document.getElementById("turn").innerHTML = "Tour : " + turn;
}

function play(x, y) {
    if (plateau[x][y] === 0) {
        plateau[x][y] = turn;
        document.getElementById(x.toString() + y.toString()).style.backgroundImage = "url(" + img.get(turn) + ")";
        if (!check()) {
            if (turn === "X") {
                turn = "O";
            } else {
                turn = "X";
            }
            document.getElementById("turn").innerHTML = "Tour : " + turn;
        } else {
            document.body.style.pointerEvents = "none";
        }
    }
}

function check() {
    for (let i = 0; i < 3; i++) {
        let every = plateau[i].every(p => p === turn);
        if (every) {
            document.getElementById("turn").innerHTML = "Victoire : " + turn;
            return true;
        }
    }

    let newlist = [
        [
            plateau[0][0],
            plateau[1][0],
            plateau[2][0]

        ],    
        [          
            plateau[0][1],
            plateau[1][1],
            plateau[2][1]

        ],    
        [         
            plateau[0][2],
            plateau[1][2],
            plateau[2][2]
        ],
        
    ];

    for (let i = 0; i < 3; i++) {
        let every = newlist[i].every(p => p === turn);
        if (every) {
            document.getElementById("turn").innerHTML = "Victoire : " + turn;
            return true;
        }
    }

    if (plateau[0][0] === turn
        && plateau[1][1] === turn
        && plateau[2][2] === turn) 
    {
        document.getElementById("turn").innerHTML = "Victoire : " + turn;
        return true;
    }

    if (plateau[0][2] === turn
        && plateau[1][1] === turn
        && plateau[2][0] === turn) 
    {
        document.getElementById("turn").innerHTML = "Victoire : " + turn;
        return true;
    }

    let x = 0;
    for (let i = 0; i < 3; i++) {
        for (let y = 0; y < 3; y++) {
            if (plateau[i][y] !== 0) {
                x++;
            }
        }
    }

    if (x === 9) {
        document.getElementById("turn").innerHTML = "Égalité";
        return true;
    }

    return false;
}

newGame();